"""
8. Вводятся три разных числа. Найти, какое из них является средним
(больше одного, но меньше другого).
"""
a = float(input("Введите 1е число: "))
b = float(input("Введите 2е число: "))
c = float(input("Введите 3е число: "))
if a > b and a < c or a < b and a > c:
    print("Ответ: ", a)
elif b > a and b < c or b < a and b > c:
    print("Ответ: ", b)
else:
    print("Ответ: ", c)